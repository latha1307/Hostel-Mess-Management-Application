const express = require('express');
const { openPool } = require('../database');
const router = express.Router();

// Route for calculating the mess bill
router.post('/calculate-bill', async (req, res) => {
    const { selectedMonth, selectedYear } = req.body;
    console.log(req.body)    
    try {
        const pool = await openPool();
        const request = pool.request();

        // Create start and end dates for the selected month
        const startDate = new Date(selectedYear, selectedMonth - 1, 1); 
        const endDate = new Date(selectedYear, selectedMonth, 0); 

        // Declare parameters
        request.input('Month', selectedMonth);
        request.input('Year', selectedYear);
        request.input('StartDate', startDate); 
        request.input('EndDate', endDate);     

        

        // Fetch total groceries consumed
        const groceriesResult = await request.query(`
            SELECT SUM(ConsumedCostTotal) AS TotalGroceries
            FROM ConsumedProducts
            WHERE DateofConsumed >= @StartDate AND DateofConsumed <= @EndDate
        `);
        const totalGroceries = groceriesResult.recordset[0]?.TotalGroceries || 0;

        // Fetch total essentials
        const essentialsResult = await request.query(`
            SELECT SUM(TotalCost) AS TotalEssentials
            FROM GasUsage
            WHERE DateUsed >= @StartDate AND DateUsed <= @EndDate
        `);
        const totalEssentials = essentialsResult.recordset[0]?.TotalEssentials || 0;

        // Fetch total staff salaries
        const salariesResult = await request.query(`
            SELECT SUM(Salary) AS TotalStaffSalaries
            FROM StaffSalaries
            WHERE DateIssued >= @StartDate AND DateIssued <= @EndDate
        `);
        const totalStaffSalaries = salariesResult.recordset[0]?.TotalStaffSalaries || 0;

        // Fetch total headcount
        const attendanceResult = await request.query(`
            SELECT SUM(BillableDays) AS TotalHeadCount
            FROM StudentsAttendance
            WHERE MonthYear >= @StartDate AND MonthYear <= @EndDate
        `);
        const totalHeadCount = attendanceResult.recordset[0]?.TotalHeadCount || 0;

        // Construct the response
        const response = {
            totalGroceries,
            totalEssentials,
            totalStaffSalaries,
            totalHeadCount,
        };

       

        // Send the response
        res.status(200).json(response);
    } catch (error) {
        console.error('Error calculating bill:', error);
        res.status(500).json({ error: 'An error occurred while calculating the bill.' });
    }
});

module.exports = router;
