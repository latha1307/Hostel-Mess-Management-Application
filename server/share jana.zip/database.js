const sql = require('mssql/msnodesqlv8');

const config = {
    server: 'localhost\\SQLEXPRESS', // Use the named instance if applicable
    database: 'HostelManagementDB',
    options: {
        trustedConnection: true,
        driver: 'msnodesqlv8',
    }
};



async function openPool() {
    try {
        const pool = await sql.connect(config);
        console.log('Database connected!');
        return pool;
    } catch (err) {
        console.error('Database connection failed:', err);
        throw err;
    }
}

module.exports = { openPool };
