const sql = require('mssql/msnodesqlv8');
const express = require("express");
const { openPool } = require('../database');

const router = express.Router();


router.get('/admin/leave-verification', async (req, res) => {

    try {
        
        const pool = await openPool(); 

        const query = `
            SELECT 
                student_id,
                StudentName,
                RegNo,
                DateFrom,
                DateTo,
                NoOfDays
            FROM [HostelManagementDB].[dbo].[MonthlyLeaveVerification] 
        `;

        const result = await pool.request().query(query);

        const leaveVerification = result.recordset.map(product => ({
            student_id: product.student_id,
            StudentName: product.StudentName,
            RegNo: product.RegNo,
            DateFrom: product.DateFrom,
            DateTo: product.DateTo,
            NoOfDays: product.NoOfDays

        }));

        res.status(200).json(leaveVerification);
    } catch (error) {
        console.error('Error fetching consumed products:', error);
        res.status(500).json({ message: "Server error: " + error.message });
    }
});

router.post('/admin/leave-verification/approved', async (req, res) => {
    const { studentID, dateFrom, dateTo, status,noOfDays } = req.body;
    console.log(req.body);
    
    try {
        const pool = await openPool();


        // Step 1: Update the leave status in the StudentsLeaveHistory table
        await pool.request()
            .input('student_id', sql.Char(13), studentID)
            .input('DateFrom', sql.Date, dateFrom)
            .input('DateTo', sql.Date, dateTo)
            .input('status', sql.VarChar(50), status) 
            .query(`
                UPDATE [HostelManagementDB].[dbo].[MonthlyLeaveVerification]
                SET status = @status
                WHERE student_id = @student_id AND DateFrom = @DateFrom AND DateTo = @DateTo
            `);

        if (status === 'Approved') {
        
            await pool.request()
                .input('StudentID', sql.Char(13), studentID)
                .input('DateFrom', sql.Date, dateFrom)
                .input('DateTo', sql.Date, dateTo)
                .input('NoOfDays', sql.Int, noOfDays)
                .query(`
                    UPDATE [HostelManagementDB].[dbo].[StudentsAttendance]
                    SET BillableDays = BillableDays - @NoOfDays + 2, NoOfLeaveDays = NoOfLeaveDays + @NoOfDays
                    WHERE StudentID = @StudentID and calculated = 0
                `);

                await pool.request()
                .input('student_id', sql.Char(13), studentID)
                .input('DateFrom', sql.Date, dateFrom)
                .input('DateTo', sql.Date, dateTo)
                .input('status', sql.VarChar(50), status) 
                .query(`
                    UPDATE [HostelManagementDB].[dbo].{StudentsLeaveHistory]
                    SET Status = @status
                    WHERE student_id = @student_id AND DateFrom = @DateFrom AND DateTo = @DateTo
                `);
        }
        await pool.request()
        .input('student_id', sql.Char(13), studentID)
        .input('DateFrom', sql.Date, dateFrom)
        .input('DateTo', sql.Date, dateTo)
        .query(`
            DELETE FROM [HostelManagementDB].[dbo].[MonthlyLeaveVerification]
            WHERE student_id = @student_id AND DateFrom = @DateFrom AND DateTo = @DateTo
        `);
        
        res.status(200).json({ message: 'Leave request processed and deleted successfully' });
        // Step 3: Delete the leave request from StudentsLeaveRequests table
     } catch (error) {
        console.error('Error approving leave request:', error);
        res.status(500).json({ message: "Server error: " + error.message });
    }
});


router.put('/admin/leave-verification/update', async (req, res) => {
    const { studentID, newDateFrom, newDateTo, noOfDays } = req.body;
    console.log(req.body);  

    try {
        const pool = await openPool();
        const transaction = new sql.Transaction(pool);  
        await transaction.begin();

        try {
            // Step 1: Retrieve the old leave details from MonthlyLeaveVerifications based on studentID
            const oldLeaveResult = await transaction.request()
                .input('student_id', sql.Char(13), studentID)
                .query(`
                    SELECT DateFrom, DateTo, NoOfDays 
                    FROM [HostelManagementDB].[dbo].[MonthlyLeaveVerification]
                    WHERE student_id = @student_id AND status = 'Confirmed'
                `);

            if (oldLeaveResult.recordset.length === 0) {
               
                await transaction.rollback();
                return res.status(404).json({ message: 'No leave found for the provided student ID.' });
            }

            const oldLeave = oldLeaveResult.recordset[0];
            const oldDateFrom = oldLeave.DateFrom;
            const oldDateTo = oldLeave.DateTo;
            const oldNoOfDays = oldLeave.NoOfDays;  


            const newDaysCount = noOfDays
            
            // Step 2: Update leave details in the MonthlyLeaveVerifications table
            await transaction.request()
                .input('student_id', sql.Char(13), studentID)
                .input('OldDateFrom', sql.Date, oldDateFrom)
                .input('OldDateTo', sql.Date, oldDateTo)
                .input('NewDateFrom', sql.Date, newDateFrom)
                .input('NewDateTo', sql.Date, newDateTo)
                .input('NoOfDays', sql.Int, newDaysCount)
                .query(`
                    UPDATE [HostelManagementDB].[dbo].[MonthlyLeaveVerification]
                    SET DateFrom = @NewDateFrom, 
                        DateTo = @NewDateTo, 
                        NoOfDays = @NoOfDays 
                    WHERE student_id = @student_id 
                      AND DateFrom = @OldDateFrom 
                      AND DateTo = @OldDateTo
                `);



            // Step 4: Update leave history in StudentsLeaveHistory
            await transaction.request()
                .input('student_id', sql.Char(13), studentID)
                .input('OldDateFrom', sql.Date, oldDateFrom)
                .input('OldDateTo', sql.Date, oldDateTo)
                .input('NewDateFrom', sql.Date, newDateFrom)
                .input('NewDateTo', sql.Date, newDateTo)
                .input('NoOfDays', sql.Int, newDaysCount)
                .query(`
                    UPDATE [HostelManagementDB].[dbo].[StudentsLeaveHistory]
                    SET DateFrom = @NewDateFrom, 
                        DateTo = @NewDateTo, 
                        NoOfDays = @NoOfDays
                    WHERE student_id = @student_id 
                      AND DateFrom = @OldDateFrom 
                      AND DateTo = @OldDateTo
                `);

            // Commit the transaction after all updates
            await transaction.commit();
            res.status(200).json({ message: 'Leave verification details updated successfully' });
        } catch (error) {
            // Rollback the transaction in case of any error
            await transaction.rollback();
            console.error('Error in updating leave details:', error);
            res.status(500).json({ message: "Server error: " + error.message });
        }
    } catch (error) {
        // Log any errors during the pool connection
        console.error('Error in updating leave details:', error);
        res.status(500).json({ message: "Server error: " + error.message });
    }
});




router.delete('/admin/leave-verification/reject', async (req, res) => {
    const { studentID, dateFrom, dateTo, noOfDays } = req.body;

    try {
        const pool = await openPool();

        // Start a transaction
        const transaction = new sql.Transaction(pool);
        await transaction.begin();

        try {
            // Update the status in the History table
            await transaction.request()
                .input('student_id', sql.Char(13), studentID)
                .input('DateFrom', sql.Date, dateFrom)
                .input('DateTo', sql.Date, dateTo)
                .input('NoOfDays', sql.Int, noOfDays)
                .query(`
                    UPDATE [HostelManagementDB].[dbo].[MonthlyLeaveVerification]
                    SET Status = 'Rejected' 
                    WHERE student_id = @student_id AND DateFrom = @dateFrom AND DateTo = @dateTo
                `);

            // Delete the leave request from StudentsLeaveRequests table
            await transaction.request()
                .input('student_id', sql.Char(13), studentID)
                .input('DateFrom', sql.Date, dateFrom)
                .input('DateTo', sql.Date, dateTo)
                .input('NoOfDays', sql.Int, noOfDays)
                .query(`
                    UPDATE [HostelManagementDB].[dbo].[StudentsAttendance]
                    SET NoOfDays = NoOfDays - @NoOfDays
                    WHERE student_id = @student_id AND DateFrom = @dateFrom AND DateTo = @dateTo
                `);

                const result = await transaction.request()
                .input('student_id', sql.Char(13), studentID)
                .input('DateFrom', sql.Date, dateFrom)
                .input('DateTo', sql.Date, dateTo)
                .input('NoOfDays', sql.Int, noOfDays)
                .query(`
                    DELETE [HostelManagementDB].[dbo].[MonthlyLeaveVerification]
                    WHERE student_id = @student_id AND DateFrom = @dateFrom AND DateTo = @dateTo
                `);

                if (result.rowsAffected.length === 0 || result.rowsAffected[0] === 0) {
                    await transaction.rollback();
                    return res.status(404).json({ message: 'Leave request not found' });
                }
                

            // Commit the transaction if everything goes well
            await transaction.commit();
            res.status(200).json({ message: 'Leave request deleted successfully and status updated in history' });
        } catch (error) {
            // Roll back the transaction in case of error
            await transaction.rollback();
            console.error('Transaction error:', error);
            res.status(500).json({ message: "Server error: " + error.message });
        }

    } catch (error) {
        console.error('Error deleting leave request:', error);
        res.status(500).json({ message: "Server error: " + error.message });
    }
});



module.exports = router;
